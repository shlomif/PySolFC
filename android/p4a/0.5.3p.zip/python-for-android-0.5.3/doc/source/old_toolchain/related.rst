Related projects
================

- PGS4A: http://pygame.renpy.org/ (thanks to Renpy to make it possible)
- Android scripting: http://code.google.com/p/android-scripting/
- Python on a chip: http://code.google.com/p/python-on-a-chip/

